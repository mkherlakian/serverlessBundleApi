
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'designstripe',
  applicationName: 'ds-motion-video',
  appUid: 'MgLJFsWQF40JqbMyVq',
  orgUid: 'e5c1a432-01c1-4789-8f1e-eb380f4eef52',
  deploymentUid: 'a2e5ec94-2ef5-49e6-bc93-eabc38e7ebda',
  serviceName: 'ds-motionvideomaker-backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'ds-motionvideomaker-backend-dev-hello', timeout: 6 };

try {
  const userHandler = require('./src/initializeTranscribe.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}